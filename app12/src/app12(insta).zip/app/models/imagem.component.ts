export class Imagem{
    constructor(
        public estado: string,
        public url: string
    ){}   

}
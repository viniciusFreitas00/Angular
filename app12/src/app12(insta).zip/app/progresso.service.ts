export class Progresso{
    public status: string;
    public estado: any;
}
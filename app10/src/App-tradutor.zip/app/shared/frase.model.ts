export class Frase{
    constructor(public fraseENG: string,public frasePTBR: string){}
}
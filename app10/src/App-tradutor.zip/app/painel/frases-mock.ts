import { Frase } from '../shared/frase.model'
// Mock = arquivo para guardar dados.
export const FRASES : Array<Frase> = [
    { fraseENG: 'i Like to learn', frasePTBR: 'Eu gosto de aprender' },
    { fraseENG: 'i watch tv', frasePTBR: 'Eu assisto tv' },
    { fraseENG: 'how are you?', frasePTBR: 'Como vai você?' },
    { fraseENG: 'i eat bread', frasePTBR: 'Eu como pão' },

]
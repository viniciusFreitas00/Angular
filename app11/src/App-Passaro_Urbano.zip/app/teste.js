console.log("aallalalal");

function soma (){
    return 2+2;
}

console.log(soma());
console.log(soma);